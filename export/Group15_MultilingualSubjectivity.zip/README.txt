GITHUB repo link (also present in the report at the bottom):
https://github.com/JakubMroz4/subjectivity-detection
