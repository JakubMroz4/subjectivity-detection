The model training code can be found in jupyter notebook files, titled after their subtask.
Baseline comparison is in LANG_baseline files


necessary python dependencies:
pandas, scikit-learn, torch, transformers, SentencePiece 
matplotlib